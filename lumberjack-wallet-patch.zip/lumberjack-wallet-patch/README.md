# Lumberjack Ninja — Wallet Connection Patch

## What's included
- `src/wagmi.ts` — NEW: Wagmi + RainbowKit config (MetaMask, Rainbow, WalletConnect)
- `src/components/ConnectWallet.tsx` — NEW: Custom themed connect wallet button
- `src/main.tsx` — MODIFIED: Wrapped app with WagmiProvider, QueryClientProvider, RainbowKitProvider
- `src/App.tsx` — MODIFIED: Added ConnectWallet button to header
- `package.json` — MODIFIED: Added @rainbow-me/rainbowkit, wagmi, viem, @tanstack/react-query

## How to apply

1. Extract this zip into your project root (overwrite existing files when prompted)
2. Run:
   ```bash
   npm install
   ```
3. Replace the demo WalletConnect project ID in `src/wagmi.ts` with your own from https://cloud.walletconnect.com
4. Commit and push:
   ```bash
   git add .
   git commit -m "feat: add wallet connection (RainbowKit + MetaMask + WalletConnect + Rainbow)"
   git push
   ```

## Supported wallets
- MetaMask
- Rainbow
- WalletConnect (any WC-compatible wallet)

## Supported chains
- Ethereum Mainnet
- Base
- Optimism
- Arbitrum

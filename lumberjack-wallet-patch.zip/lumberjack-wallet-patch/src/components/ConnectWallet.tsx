import { ConnectButton } from '@rainbow-me/rainbowkit';

export function ConnectWallet() {
  return (
    <ConnectButton.Custom>
      {({
        account,
        chain,
        openAccountModal,
        openChainModal,
        openConnectModal,
        authenticationStatus,
        mounted,
      }) => {
        const ready = mounted && authenticationStatus !== 'loading';
        const connected =
          ready &&
          account &&
          chain &&
          (!authenticationStatus || authenticationStatus === 'authenticated');

        return (
          <div
            {...(!ready && {
              'aria-hidden': true,
              style: {
                opacity: 0,
                pointerEvents: 'none',
                userSelect: 'none',
              },
            })}
          >
            {(() => {
              if (!connected) {
                return (
                  <button
                    onClick={openConnectModal}
                    type="button"
                    className="flex items-center gap-2 px-3 py-1.5 md:px-4 md:py-2 bg-gradient-to-r from-purple-700 via-purple-600 to-purple-700 hover:from-purple-600 hover:via-purple-500 hover:to-purple-600 text-purple-100 text-sm font-bold rounded-lg transition-all border border-purple-500/50 shadow-lg shadow-purple-900/30 hover:shadow-purple-700/40 transform hover:scale-[1.02] active:scale-[0.98]"
                  >
                    <svg width="16" height="16" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg" className="shrink-0">
                      <path d="M21 12C21 16.9706 16.9706 21 12 21C7.02944 21 3 16.9706 3 12C3 7.02944 7.02944 3 12 3C16.9706 3 21 7.02944 21 12Z" stroke="currentColor" strokeWidth="2"/>
                      <path d="M15 12C15 13.6569 13.6569 15 12 15C10.3431 15 9 13.6569 9 12C9 10.3431 10.3431 9 12 9C13.6569 9 15 10.3431 15 12Z" fill="currentColor"/>
                      <path d="M12 3V6" stroke="currentColor" strokeWidth="2" strokeLinecap="round"/>
                      <path d="M12 18V21" stroke="currentColor" strokeWidth="2" strokeLinecap="round"/>
                      <path d="M3 12H6" stroke="currentColor" strokeWidth="2" strokeLinecap="round"/>
                      <path d="M18 12H21" stroke="currentColor" strokeWidth="2" strokeLinecap="round"/>
                    </svg>
                    <span className="hidden sm:inline">Connect Wallet</span>
                    <span className="sm:hidden">Wallet</span>
                  </button>
                );
              }

              if (chain.unsupported) {
                return (
                  <button
                    onClick={openChainModal}
                    type="button"
                    className="flex items-center gap-2 px-3 py-1.5 md:px-4 md:py-2 bg-red-800/60 hover:bg-red-700/60 text-red-200 text-sm font-bold rounded-lg transition-all border border-red-600/50"
                  >
                    ⚠️ Wrong network
                  </button>
                );
              }

              return (
                <div className="flex items-center gap-2">
                  <button
                    onClick={openChainModal}
                    type="button"
                    className="flex items-center gap-1.5 px-2 py-1.5 md:px-3 md:py-2 bg-amber-800/40 hover:bg-amber-700/50 text-amber-200 text-xs md:text-sm font-medium rounded-lg transition-all border border-amber-700/40"
                  >
                    {chain.hasIcon && (
                      <div
                        className="w-4 h-4 rounded-full overflow-hidden"
                        style={{ background: chain.iconBackground }}
                      >
                        {chain.iconUrl && (
                          <img
                            alt={chain.name ?? 'Chain icon'}
                            src={chain.iconUrl}
                            className="w-4 h-4"
                          />
                        )}
                      </div>
                    )}
                    <span className="hidden md:inline">{chain.name}</span>
                  </button>

                  <button
                    onClick={openAccountModal}
                    type="button"
                    className="flex items-center gap-1.5 px-2 py-1.5 md:px-3 md:py-2 bg-gradient-to-r from-purple-800/50 to-purple-700/50 hover:from-purple-700/60 hover:to-purple-600/60 text-purple-100 text-xs md:text-sm font-bold rounded-lg transition-all border border-purple-600/40"
                  >
                    <div className="w-2 h-2 rounded-full bg-green-400 animate-pulse"></div>
                    {account.displayName}
                    {account.displayBalance ? (
                      <span className="hidden sm:inline text-purple-300 font-normal">
                        ({account.displayBalance})
                      </span>
                    ) : null}
                  </button>
                </div>
              );
            })()}
          </div>
        );
      }}
    </ConnectButton.Custom>
  );
}

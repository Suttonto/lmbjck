import { getDefaultConfig } from '@rainbow-me/rainbowkit';
import { mainnet, base, optimism, arbitrum } from 'wagmi/chains';
import {
  rainbowWallet,
  metaMaskWallet,
  walletConnectWallet,
} from '@rainbow-me/rainbowkit/wallets';
import { connectorsForWallets } from '@rainbow-me/rainbowkit';

const connectors = connectorsForWallets(
  [
    {
      groupName: 'Popular',
      wallets: [
        metaMaskWallet,
        rainbowWallet,
        walletConnectWallet,
      ],
    },
  ],
  {
    appName: 'Lumberjack Ninja',
    projectId: 'b1e8d065e6e91bfb3e2e53f03a63ddb3', // Demo WalletConnect project ID
  }
);

export const config = getDefaultConfig({
  appName: 'Lumberjack Ninja',
  projectId: 'b1e8d065e6e91bfb3e2e53f03a63ddb3', // Demo WalletConnect project ID - replace with your own
  chains: [mainnet, base, optimism, arbitrum],
  wallets: [
    {
      groupName: 'Popular',
      wallets: [
        metaMaskWallet,
        rainbowWallet,
        walletConnectWallet,
      ],
    },
  ],
});
